document.addEventListener('DOMContentLoaded', function () {
	var currentUrl = "";	
	chrome.tabs.getSelected(undefined, function(tab) {
		incognito = tab.incognito;
		currentUrl = tab.url;	
		var longUrl = document.getElementById("longUrl");
		longUrl.value = currentUrl;
	});	

	$('#generate').live('click',function(){
		chrome.extension.sendRequest({ msg: "saveLink" });
	});
});
