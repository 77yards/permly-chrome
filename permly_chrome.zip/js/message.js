	var div = document.createElement("div");
	div.setAttribute("style","position:absolute;left:30%;top:30%;padding:5px;border: 1px solid #000000; background: none repeat scroll 0 0 #dddddd;z-index:10000;width:400px;height:200px;");
	div.setAttribute("id", "permly-popup" );

	div.innerHTML += "<p style='font-weight:bold;font-family:Arial;font-size:14px;color:#000000;margin:2px;padding:0;'>perm.ly Info</p>";
	div.innerHTML += "<p id='permly-info-div-title' style='font-weight:bold;font-style:normal;font-family:Arial;font-size:12px;color:#4f4f4f;margin:0;padding:0;background: none repeat scroll 0 0 #dddddd;'>Loading</p>";
	div.innerHTML += "<p id='permly-info-div-createdby' style='font-style:normal;font-family:Arial;font-size:12px;color:#4f4f4f;margin:0;padding:0;background: none repeat scroll 0 0 #dddddd;'>" + "</p>";
	div.innerHTML += "<p id='permly-info-div-clicks' style='font-style:normal;font-family:Arial;font-size:12px;color:#4f4f4f;margin:0;padding:0;background: none repeat scroll 0 0 #dddddd;'>" + "</p>";
	document.body.appendChild(div);