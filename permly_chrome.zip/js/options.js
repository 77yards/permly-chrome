var apiKey = "";

function loadOptions() {
	var _apikey = localStorage["api_key"];

	if (_apikey == undefined) {
		_apikey = apiKey;
	}
	var permly_apikey = document.getElementById("permly_apikey");
	permly_apikey.value = _apikey; 
}

function saveApiKey() {
	var permly_apikey = document.getElementById("permly_apikey");
	if(permly_apikey.value != "")
		localStorage["api_key"] = permly_apikey.value;
	else
		alert("Please enter your perm.ly API Key");
}

function clickTestApi() {
	var permly_apikey = document.getElementById("permly_apikey");
	if(permly_apikey.value != ""){
		var apikey = localStorage["api_key"];
		if (apikey == undefined){
			apikey = permly_apikey.value;
			localStorage["api_key"] = permly_apikey.value;
		}
		
		var permlyURL = "http://api.permly.com/?remote_service=rs_external_api&interface=eai_permly&action=get_user&key="+apikey + "&version=1.0";

		var postData = {"data":''};	
		var json = JSON.stringify(postData);

		var request = new XMLHttpRequest();
		request.open("POST", permlyURL, true);
		request.onreadystatechange = function() { 
			if (request.readyState == 4) {
				var result = JSON.parse( request.responseText );
				if(!result.Error)
				{
					alert( "Valid API Key!" );
				}else 
				{
					alert( "Error validating API Key: " + result.Error.response);
				}
			}
		};
		request.setRequestHeader("Content-type","application/x-www-form-urlencoded");			
		request.send("json=" + json);			
	}else
		alert("Please enter your perm.ly API Key");
}

document.addEventListener('DOMContentLoaded', function () {
	document.querySelector('#testApi').addEventListener('click', clickTestApi);	
	document.querySelector('#saveApi').addEventListener('click', saveApiKey);
	loadOptions();
});