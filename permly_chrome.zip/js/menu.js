var contexts = ["page","link"];
for (var i = 0; i < contexts.length; i++) {
	var context = contexts[i];
	if(context == "page"){
		var title = "Create perm.ly link";
		var id = chrome.contextMenus.create({"title": title, "contexts":[context],"onclick": saveLink});
	}

	if(context == "link"){
		var title = "Create perm.ly link";
		var id = chrome.contextMenus.create({"title": title, "contexts":[context],"onclick": saveLink});
	}
}

function saveLink(info, tab){
	var permlyURL = 'http://api.permly.com/?remote_service=rs_external_api&interface=eai_permly&action=save_link';

	permlyURL = permlyURL + "&key=" + localStorage["api_key"];
	permlyURL = permlyURL + "&version=1.0";
	
	var linkUrl = info.linkUrl;
	var pageUrl = info.pageUrl;

	if(linkUrl != undefined){
		var data = {"target": window.encodeURIComponent(linkUrl)};
		var postData = {"data":data};	
		var json = JSON.stringify(postData);

		var request = new XMLHttpRequest();
		request.open("POST", permlyURL, true);

		request.onreadystatechange = function() { 
			processResponse( request,linkUrl);
		};

		request.setRequestHeader("Content-type","application/x-www-form-urlencoded");			
		request.send("json=" + json);
		
	}else if(pageUrl != undefined){
		var data = {"target": window.encodeURIComponent(pageUrl),"url_key": 'mukesh456'};
		var postData = {"data":data};	
		var json = JSON.stringify(postData);

		var request = new XMLHttpRequest();
		request.open("POST", permlyURL, true);

		request.onreadystatechange = function() { 
			processResponse( request,pageUrl);
		};

		request.setRequestHeader("Content-type","application/x-www-form-urlencoded");			
		request.send("json=" + json);
	}

}

function processResponse(request,url){
	if (request.readyState == 4) {
		var result = JSON.parse( request.responseText );

		if (!result.Error)
		{
			var shortUrl = 'http://perm.ly/'+result.data.url_key;
			copyLinkToClipboard(shortUrl);
			drawInfo(shortUrl);
		}
		else if(result.Error.code == "1550"){
			showMyLinkDetail(url);
			
		}else{
			alert( "Error while processing request. Status code:" + result.Error.code+ "; Status text: " + result.Error.response);
		}
	}
}

function showMyLinkDetail(url){
	getLinkDetail(url);		
}

function getLinkDetail(url){
	var permlyURL = 'http://api.permly.com/?remote_service=rs_external_api&interface=eai_permly&action=get_link_by_target';
	permlyURL = permlyURL + "&key=" + localStorage["api_key"];
	permlyURL = permlyURL + "&version=1.0";

	var data = {"target": encodeURIComponent(url)};
	var postData = {"data":data};	
	var json = JSON.stringify(postData);

	var request = new XMLHttpRequest();
	request.open("POST", permlyURL, true);
	request.onreadystatechange = function() { 
		showDetail( request, url);
	};
	request.setRequestHeader("Content-type","application/x-www-form-urlencoded");		
	request.send("json=" + json);			
}

function showDetail( request, url){
	if (request.readyState == 4) {
		var result = JSON.parse( request.responseText );
		if (!result.Error)
		{
			for (var i=0;i<result.data.length;i++) {
				var createdBy = result.data[i].account;
				var title = 'http://dev.perm.ly/'+result.data[i].url_key;
				copyLinkToClipboard(title);
				drawInfo(title);
			}

		}else{
			alert( "Error while fetching perm.ly link information. Status code:" + jsObject.status_code+ "; Status text: " + jsObject.status_txt );
		}

	}
}

function drawPreview(url)
{
	var div = document.createElement('div');
	div.setAttribute("style","float:center;position:relative;top: 1px; left: 1px;min-height: 5em;width: 25em;padding:5px;border: 1px solid #000000; background: none repeat scroll 0 0 #dddddd;z-index:4;opacity:1.0;");
	div.setAttribute("id", "permly-info-div" );

	div.innerHTML += "<p style='font-weight:bold;font-family:Arial;font-size:14px;color:#000000;margin:2px;padding:0;'>perm.ly Info</p>";
	div.innerHTML += "<p id='permly-info-div-title' style='font-weight:bold;font-style:normal;font-family:Arial;font-size:12px;color:#4f4f4f;margin:0;padding:0;background: none repeat scroll 0 0 #dddddd;'>Loading</p>";
	div.innerHTML += "<p id='permly-info-div-createdby' style='font-style:normal;font-family:Arial;font-size:12px;color:#4f4f4f;margin:0;padding:0;background: none repeat scroll 0 0 #dddddd;'>" + "</p>";
	div.innerHTML += "<p id='permly-info-div-clicks' style='font-style:normal;font-family:Arial;font-size:12px;color:#4f4f4f;margin:0;padding:0;background: none repeat scroll 0 0 #dddddd;'>" + "</p>";
	div.innerHTML += "<p id='permly-info-div-url' style='font-style:normal;font-family:Arial;font-size:12px;color:#4f4f4f;margin:0;padding:0;background: none repeat scroll 0 0 #dddddd;'>URL : <a style='color:#4f4f4f;' href='" + url + "' target='_blank'>" + url + "</a></p>";
	div.innerHTML += "<p id='permly-info-div-more' style='font-style:normal;font-family:Arial;font-size:12px;color:#4f4f4f;margin:0;padding:0;background: none repeat scroll 0 0 #dddddd;text-align:right'><a style='color:#4f4f4f;' href='" + url + "+' target='_blank'>More Info..</a></p>";
	
	return div;       
}

function copyLinkToClipboard(link) {
	var copyDiv = document.createElement('div');
	copyDiv.contentEditable = true;
	document.body.appendChild(copyDiv);
	copyDiv.innerHTML = link;
	copyDiv.unselectable = "off";
	copyDiv.focus();
	document.execCommand('SelectAll');
	document.execCommand("Copy", false, null);
	document.body.removeChild(copyDiv);
}

chrome.extension.onRequest.addListener(
    function(request, sender, sendResponse){	    
        if(request.msg == "saveLink"){ 
		chrome.tabs.getSelected(undefined, function(tab) {
			incognito = tab.incognito;
			var currentUrl = tab.url;	
			savePageLink(currentUrl);
		});    			
	}
    }
);

function drawInfo(url){
	chrome.tabs.executeScript(null, { code : "var div = document.createElement('div');div.setAttribute('style','position:absolute;left:30%;top:30%;padding:5px;border: 1px solid #000000; background: none repeat scroll 0 0 #dddddd;z-index:10000;width:400px;height:100px;text-align:left;');div.setAttribute('id', 'permly-popup' );div.innerHTML += \"<p style='font-weight:bold;font-family:Arial;font-size:14px;color:#000000;margin:2px;padding:0;'>Permly Info</p>\";div.innerHTML += \"<p id='permly-info-div-url' style='font-style:normal;font-family:Arial;font-size:12px;color:#4f4f4f;margin:0;padding:10px;text-align:left;'>URL : <a style='color:#4f4f4f;' href='" + url + "' target='_blank'>" + url + "</a></p>\";document.body.appendChild(div);setTimeout(\"document.body.removeChild(document.getElementById('permly-popup'))\",7000);"},function(tab){
			
	});	
}

function savePageLink(link){
	var permlyURL = 'http://api.permly.com/?remote_service=rs_external_api&interface=eai_permly&action=save_link';

	permlyURL = permlyURL + "&key=" + localStorage["api_key"];
	permlyURL = permlyURL + "&version=1.0";
	var linkUrl = link;
	
	if(linkUrl != undefined){
		var data = {"target": window.encodeURIComponent(linkUrl)};
		var postData = {"data":data};	
		var json = JSON.stringify(postData);

		var request = new XMLHttpRequest();
		request.open("POST", permlyURL, true);

		request.onreadystatechange = function() { 
			processResponse( request,linkUrl);
		};

		request.setRequestHeader("Content-type","application/x-www-form-urlencoded");			
		request.send("json=" + json);
	}
}

//chrome.browserAction.onClicked.addListener(loadPopup);

/*function loadPopup(){
	chrome.tabs.executeScript(null, { file : "js/popup.js"}); 

	$('#generate').live('click',function(){
		chrome.extension.sendRequest({ msg: "saveLink" });
	});	
}*/
